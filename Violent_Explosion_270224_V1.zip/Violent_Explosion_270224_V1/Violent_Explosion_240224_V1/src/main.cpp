#include "main.h"
#include "lemlib/api.hpp"

//Chassis constructor - LemLib, which is for auton

// drivetrain motors
pros::Motor left_front_motor(1, false); // port 1, not reversed
pros::Motor left_middle_motor(2, false); // port 2, not reversed
pros::Motor left_back_motor(3, false); // port 3, not reversed
pros::Motor right_front_motor(14, true); // port 4, reversed
pros::Motor right_middle_motor(5, true); // port 5, reversed
pros::Motor right_back_motor(20, true); // port 6, reversed
 
// drivetrain motor groups
pros::MotorGroup left_side_motors({left_front_motor, left_middle_motor, left_back_motor});
pros::MotorGroup right_side_motors({right_front_motor, right_middle_motor, right_back_motor});
 
lemlib::Drivetrain_t drivetrain {
    &left_side_motors, // left drivetrain motors
    &right_side_motors, // right drivetrain motors
    262, // track width
    3.25, // wheel diameter
    600 // wheel rpm
};
 
// left tracking wheel encoder
pros::ADIEncoder left_enc('A', 'B', true); // ports A and B, reversed
// right tracking wheel encoder
pros::Rotation right_rot(1, false); // port 1, not reversed
// back tracking wheel encoder
pros::ADIEncoder back_enc('C', 'D', false); // ports C and D, not reversed
 
// left tracking wheel
lemlib::TrackingWheel left_tracking_wheel(&left_enc, 2.75, -4.6); // 2.75" wheel diameter, -4.6" offset from tracking center
// right tracking wheel
lemlib::TrackingWheel right_tracking_wheel(&right_rot, 2.75, 1.7); // 2.75" wheel diameter, 1.7" offset from tracking center
lemlib::TrackingWheel back_tracking_wheel(&back_enc, 2.75, 4.5); // 2.75" wheel diameter, 4.5" offset from tracking center
 
// inertial sensor
pros::Imu inertial_sensor(10); // port 20
 
// odometry struct
lemlib::OdomSensors_t sensors {
    nullptr, // vertical tracking wheel 1
    nullptr, // vertical tracking wheel 2
    nullptr, // horizontal tracking wheel 1
    nullptr, // we don't have a second tracking wheel, so we set it to nullptr
    &inertial_sensor // inertial sensor
};
 
// forward/backward PID
lemlib::ChassisController_t lateralController {
    8, // kP
    30, // kD
    1, // smallErrorRange
    100, // smallErrorTimeout
    3, // largeErrorRange
    500, // largeErrorTimeout
    5 // slew rate
};
 
// turning PID
lemlib::ChassisController_t angularController {
    4, // kP
    40, // kD
    1, // smallErrorRange
    100, // smallErrorTimeout
    3, // largeErrorRange
    500, // largeErrorTimeout
    40 // slew rate
};
 
 
// create the chassis
lemlib::Chassis chassislem(drivetrain, lateralController, angularController, sensors);


// Chassis constructor - EZ TEMPLATE, which is for driver control.
Drive chassis (
  // Left Chassis Ports (negative port will reverse it!)
  //   the first port is the sensored port (when trackers are not used!)
  {-1, -2, -3}

  // Right Chassis Ports (negative port will reverse it!)
  //   the first port is the sensored port (when trackers are not used!)
  ,{14, 5, 20}

  // IMU Port
  ,10

  // Wheel Diameter (Remember, 4" wheels are actually 4.125!)
  //    (or tracking wheel diameter)
  ,3.25

  // Cartridge RPM
  //   (or tick per rotation if using tracking wheels)
  ,450

  // External Gear Ratio (MUST BE DECIMAL)
  //    (or gear ratio of tracking wheel)
  // eg. if your drive is 84:36 where the 36t is powered, your RATIO would be 2.333.
  // eg. if your drive is 36:60 where the 60t is powered, your RATIO would be 0.6.
  ,0.75


  // Uncomment if using tracking wheels
  /*
  // Left Tracking Wheel Ports (negative port will reverse it!)
  // ,{1, 2} // 3 wire encoder
  // ,8 // Rotation sensor

  // Right Tracking Wheel Ports (negative port will reverse it!)
  // ,{-3, -4} // 3 wire encoder
  // ,-9 // Rotation sensor
  */

  // Uncomment if tracking wheels are plugged into a 3 wire expander
  // 3 Wire Port Expander Smart Port
  // ,1
);

void fiveballauton_blue() {
  //declarations
  pros::Motor Intake_M1(9, false);
  pros::ADIDigitalOut wing1 ('A', false);
  pros::ADIDigitalOut wing2 ('B', false);
  pros::ADIDigitalOut wing3 ('C', false);

  //auton
  chassislem.follow("blueautonp1.txt", 1000, 15);
  Intake_M1.move(127);
  pros::delay(100);
  Intake_M1.move(0);
  
  chassislem.follow("blueautonp2.txt", 1000, 15);
  Intake_M1.move(127);
  pros::delay(100);
  Intake_M1.move(0);
  wing1.set_value(true);

  chassislem.follow("blueautonp3.txt", 1000, 15);
}

/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */

void initialize() {
  pros::delay(100); // Stop the user from doing anything while legacy ports configure.

  // Configure your chassis controls
  chassis.toggle_modify_curve_with_controller(false); // Enables modifying the controller curve with buttons on the joysticks
  chassis.set_active_brake(0.1); // Sets the active brake kP. We recommend 0.1.
  // chassis.set_curve_default(0, 0); // Defaults for curve. If using tank, only the first parameter is used. (Comment this line out if you have an SD card!)  
  default_constants(); // Set the drive to your own constants from autons.cpp!

  // These are already defaulted to these buttons, but you can change the left/right curve buttons here!
  // chassis.set_left_curve_buttons (pros::E_CONTROLLER_DIGITAL_LEFT, pros::E_CONTROLLER_DIGITAL_RIGHT); // If using tank, only the left side is used. 
  // chassis.set_right_curve_buttons(pros::E_CONTROLLER_DIGITAL_Y,    pros::E_CONTROLLER_DIGITAL_A);

  // Initialize chassis and auton selector
  chassislem.calibrate();
  chassis.initialize();
  ez::as::initialize();
}



/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {
  // . . .
}



/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize() {
  // . . .
}



/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */

void autonomous() {
  
  /* chassis.reset_pid_targets(); // Resets PID targets to 0
  chassis.reset_gyro(); // Reset gyro position to 0
  chassis.reset_drive_sensor(); // Reset drive sensors to 0 */
  chassis.set_drive_brake(MOTOR_BRAKE_HOLD); // Set motors to hold.  This helps autonomous consistency.
  fiveballauton_blue();
}



/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
void opcontrol() {
  // This is preference to what you like to drive on.
  chassis.set_drive_brake(MOTOR_BRAKE_COAST);
  pros::Motor Intake_M1(9, false);
  pros::Motor Puncher(7, false);
  pros::ADIDigitalOut wing1 ('A', false);
  pros::ADIDigitalOut wing2 ('B', false);
  pros::ADIDigitalOut wing3 ('C', false);
  pros::ADIDigitalOut wing4 ('D', false);
  pros::ADIDigitalOut hang1 ('E', false);
  pros::ADIDigitalOut hang2 ('F', false);  
  pros::ADIDigitalOut hang3 ('G', false);
  pros::ADIDigitalOut hang4 ('H', false);

  int timespressed_intake;
  int timespressed_wings_rear;
  int timespressed_wings_front;
  int timespressed_hang;
  int timespressed_puncher;

  timespressed_intake = 0;
  timespressed_wings_rear = 0;
  timespressed_wings_front = 0;
  timespressed_hang = 0;
  timespressed_puncher = 0;


  while (true) {

    chassis.arcade_standard(ez::SINGLE); // Tank control
    // chassis.arcade_standard(ez::SPLIT); // Standard split arcade
    // chassis.arcade_standard(ez::SINGLE); // Standard single arcade
    // chassis.arcade_flipped(ez::SPLIT); // Flipped split arcade
    // chassis.arcade_flipped(ez::SINGLE); // Flipped single arcade
    
    if (master.get_digital_new_press(DIGITAL_L1)){
      Intake_M1.move(127);
      timespressed_intake += 1;
      if (timespressed_intake % 2 == 0) {
        Intake_M1.move(0);
      }
    }

    if (master.get_digital_new_press(DIGITAL_R1)){
      wing1.set_value(true);
      wing2.set_value(true);
      timespressed_wings_rear += 1;
      if (timespressed_intake % 2 == 0) {
        wing1.set_value(false);
        wing2.set_value(false);
      }
    }

    if (master.get_digital_new_press(DIGITAL_R2)){
      wing3.set_value(true);
      wing4.set_value(true);
      timespressed_wings_front += 1;
      if (timespressed_intake % 2 == 0) {
        wing3.set_value(false);
        wing4.set_value(false);
      }
    }

    if (master.get_digital_new_press(DIGITAL_X)){
      Puncher.move(-100);
      timespressed_puncher += 1;
      if (timespressed_puncher % 2 == 0) {
        Puncher.move(0);
      }
    }

    if (master.get_digital_new_press(DIGITAL_L2)){
      hang1.set_value(true);
      hang2.set_value(true);
      hang3.set_value(true);
      hang4.set_value(true);
      timespressed_hang += 1;
      if (timespressed_hang % 2 == 0) {
        hang1.set_value(false);
        hang2.set_value(false);
        hang3.set_value(false);
        hang4.set_value(false);
      }
    }

    pros::delay(ez::util::DELAY_TIME); // This is used for timer calculations!  Keep this ez::util::DELAY_TIME
  }
}
